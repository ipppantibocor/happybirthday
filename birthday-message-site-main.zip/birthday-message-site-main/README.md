# birthday-message-site
A short and sweet birthday message that served as a birthday card for my close friend's 20th birthday, hosted on Replit.

Has a small issue where in Firefox on the first page, the birthday cake image won't circle around. Instead, it stays inert on the top left. This issue doesn't exist in Google Chrome.
